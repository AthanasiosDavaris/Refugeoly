
package refugeoly;

interface  Game {
    
    
    
}
